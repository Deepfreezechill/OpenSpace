"""OpenSpace authentication module."""
