"""OpenSpace secret management module."""
