"""Scion authentication module."""
